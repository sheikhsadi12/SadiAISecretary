package com.sadi.secretary.faithtime

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — FaithTimeManager.kt                ║
// ║       Phase 07 · Faith + Time Mode Engine                    ║
// ║                                                              ║
// ║  সময় + দ্বীন অনুযায়ী reply tone change করে:                 ║
// ║    🌙 রাত      → soft, short, "পরে কথা হবে ইনশাআল্লাহ"      ║
// ║    🕌 জুমা     → Islamic tone, সালাম                         ║
// ║    ⏳ Busy     → very short, to the point                    ║
// ║    🌅 সকাল    → fresh, energetic                             ║
// ║    🕐 Normal  → regular Sadi tone                            ║
// ╚══════════════════════════════════════════════════════════════╝

import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════════
// TIME CONTEXT — কোন সময় কোন mode
// ══════════════════════════════════════════════════════════════
enum class TimeContext(
    val displayName: String,
    val emoji: String
) {
    LATE_NIGHT  ("রাত — ঘুমানোর সময়",   "🌙"),
    EARLY_MORNING("ভোর",                "🌅"),
    MORNING     ("সকাল",                "☀️"),
    JUMUAH      ("জুমার সময়",           "🕌"),
    AFTERNOON   ("দুপুর",               "🌤️"),
    EVENING     ("সন্ধ্যা",             "🌆"),
    NIGHT       ("রাত",                 "🌃"),
    NORMAL      ("Normal",              "🕐")
}

// ══════════════════════════════════════════════════════════════
// ACTIVE MODES — user manually set করতে পারে
// ══════════════════════════════════════════════════════════════
data class ActiveModes(
    val faithModeEnabled: Boolean = true,
    val busyModeEnabled: Boolean = false,
    val silentModeEnabled: Boolean = false,   // কোনো reply না
    val shortReplyForced: Boolean = false,    // সব reply short
    val islamicGreeting: Boolean = true       // সালাম দিয়ে শুরু
)

@Singleton
class FaithTimeManager @Inject constructor() {

    // ══════════════════════════════════════════════════════════
    // CURRENT TIME CONTEXT
    // ══════════════════════════════════════════════════════════
    fun getCurrentTimeContext(): TimeContext {
        val cal    = Calendar.getInstance()
        val hour   = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        val dow    = cal.get(Calendar.DAY_OF_WEEK)

        return when {
            // রাত ১১টা → ভোর ৪টা
            hour >= 23 || hour < 4 -> TimeContext.LATE_NIGHT

            // ভোর ৪টা → ৬টা (ফজরের সময়)
            hour in 4..5 -> TimeContext.EARLY_MORNING

            // জুমার দিন দুপুর ১২টা → ২টা
            dow == Calendar.FRIDAY && hour in 12..13 -> TimeContext.JUMUAH

            // সকাল ৬টা → ১০টা
            hour in 6..9 -> TimeContext.MORNING

            // দুপুর ১০টা → ৫টা
            hour in 10..16 -> TimeContext.AFTERNOON

            // সন্ধ্যা ৫টা → ৮টা
            hour in 17..19 -> TimeContext.EVENING

            // রাত ৮টা → ১১টা
            hour in 20..22 -> TimeContext.NIGHT

            else -> TimeContext.NORMAL
        }
    }

    // ══════════════════════════════════════════════════════════
    // PRAYER TIME CHECK — নামাজের সময়?
    // (approximate — location ছাড়া exact possible না)
    // ══════════════════════════════════════════════════════════
    fun isApproxPrayerTime(): Boolean {
        val cal  = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val min  = cal.get(Calendar.MINUTE)

        // Bangladesh approximate prayer times
        return when {
            hour == 5  && min in 0..30  -> true  // ফজর
            hour == 13 && min in 0..30  -> true  // যোহর
            hour == 16 && min in 30..59 -> true  // আসর
            hour == 18 && min in 0..30  -> true  // মাগরিব
            hour == 19 && min in 30..59 -> true  // এশা
            else -> false
        }
    }

    // ══════════════════════════════════════════════════════════
    // BUILD TIME-FAITH PROMPT — AI prompt এ inject হবে
    // ══════════════════════════════════════════════════════════
    fun buildPromptRules(
        modes: ActiveModes,
        timeContext: TimeContext = getCurrentTimeContext()
    ): String = buildString {

        appendLine("## Time + Faith Rules:")
        appendLine()

        // ── Time-based rules ──────────────────────────────────
        when (timeContext) {

            TimeContext.LATE_NIGHT -> {
                appendLine("""
                    🌙 এখন রাত। Rules:
                    • Reply খুব short এবং soft রাখো
                    • জরুরি না হলে বলো: "ঘুমাচ্ছিলাম, সকালে কথা হবে ইনশাআল্লাহ"
                    • Goodnight wish করতে পারো
                """.trimIndent())
            }

            TimeContext.EARLY_MORNING -> {
                appendLine("""
                    🌅 এখন ভোর (ফজরের সময়)। Rules:
                    • Short, peaceful reply
                    • নামাজের কথা naturally mention করতে পারো
                    • "ফজর পড়ছিলাম" বলতে পারো যদি context fit করে
                """.trimIndent())
            }

            TimeContext.JUMUAH -> {
                appendLine("""
                    🕌 আজ জুমা। Rules:
                    • জুমার সালাম দিয়ে শুরু করো: "জুমা মুবারক 🕌"
                    • Short reply — মসজিদে যাওয়ার প্রস্তুতিতে আছি
                    • Islamic tone বজায় রাখো
                    • "জুমা পড়তে যাচ্ছি, পরে কথা হবে ইনশাআল্লাহ" বলতে পারো
                """.trimIndent())
            }

            TimeContext.MORNING -> {
                appendLine("""
                    ☀️ সকাল। Rules:
                    • Fresh, positive tone
                    • "সকালে উঠলাম", "আলহামদুলিল্লাহ" naturally use করো
                    • Energetic কিন্তু short
                """.trimIndent())
            }

            TimeContext.EVENING -> {
                appendLine("""
                    🌆 সন্ধ্যা। Rules:
                    • Chill, relaxed tone
                    • মাগরিবের সময় কাছে — naturally mention করতে পারো
                """.trimIndent())
            }

            TimeContext.NIGHT -> {
                appendLine("""
                    🌃 রাত। Rules:
                    • Calm, soft tone
                    • দীর্ঘ conversation avoid করো
                """.trimIndent())
            }

            else -> appendLine("🕐 Normal time — regular tone")
        }

        appendLine()

        // ── Busy Mode ─────────────────────────────────────────
        if (modes.busyModeEnabled) {
            appendLine("""
                ⏳ BUSY MODE চালু:
                • Reply অবশ্যই ১ line এর মধ্যে
                • "ব্যস্ত আছি, পরে কথা হবে" বলতে পারো
                • Long discussion এ যাবে না
            """.trimIndent())
            appendLine()
        }

        // ── Faith Mode ────────────────────────────────────────
        if (modes.faithModeEnabled) {
            appendLine("""
                🕌 FAITH MODE চালু:
                • ইনশাআল্লাহ, আলহামদুলিল্লাহ naturally ব্যবহার করো
                • Islamic values reflect করো — কিন্তু preachy না
                • দোয়া চাইলে বা দিলে sincere থাকো
            """.trimIndent())
            appendLine()
        }

        // ── Islamic Greeting ──────────────────────────────────
        if (modes.islamicGreeting && isNewConversation()) {
            appendLine("""
                • যদি নতুন conversation শুরু হয়, সালাম দিয়ে শুরু করো:
                  "আসসালামু আলাইকুম 🙂"
            """.trimIndent())
        }

        // ── Prayer time ───────────────────────────────────────
        if (isApproxPrayerTime() && modes.faithModeEnabled) {
            appendLine("""
                • এখন নামাজের সময়ের কাছাকাছি
                • Short reply দাও — নামাজ পড়তে যাচ্ছি mention করতে পারো
            """.trimIndent())
        }
    }

    // ══════════════════════════════════════════════════════════
    // SHOULD AI REPLY?
    // Silent mode তে reply করবে না
    // ══════════════════════════════════════════════════════════
    fun shouldReply(modes: ActiveModes): Boolean {
        return !modes.silentModeEnabled
    }

    // ══════════════════════════════════════════════════════════
    // QUICK REPLY SUGGESTIONS — context based
    // ══════════════════════════════════════════════════════════
    fun getQuickReplySuggestions(timeContext: TimeContext): List<String> {
        return when (timeContext) {
            TimeContext.LATE_NIGHT -> listOf(
                "ঘুমাচ্ছিলাম, পরে কথা হবে ইনশাআল্লাহ 🌙",
                "রাত হয়ে গেছে, কাল কথা হবে ইনশাআল্লাহ",
                "Good night 🌙"
            )
            TimeContext.JUMUAH -> listOf(
                "জুমা মুবারক 🕌",
                "জুমা পড়তে যাচ্ছি, পরে কথা হবে",
                "জুমা মুবারক ভাই 🕌 পরে কথা হবে ইনশাআল্লাহ"
            )
            TimeContext.EARLY_MORNING -> listOf(
                "ফজর পড়লাম, কী বলছ?",
                "আলহামদুলিল্লাহ উঠলাম 🌅",
                "সকালে কথা হবে ইনশাআল্লাহ"
            )
            TimeContext.MORNING -> listOf(
                "সকাল হলো, কী খবর? 😊",
                "আলহামদুলিল্লাহ ভালো আছি",
                "হ্যাঁ বলো"
            )
            else -> listOf(
                "হ্যাঁ বলো",
                "accha",
                "ইনশাআল্লাহ হবে"
            )
        }
    }

    // Simple check — নতুন conversation কিনা
    // (আপাতত সবসময় false — Phase 5 memory দিয়ে later improve করা যাবে)
    private fun isNewConversation(): Boolean = false
}
