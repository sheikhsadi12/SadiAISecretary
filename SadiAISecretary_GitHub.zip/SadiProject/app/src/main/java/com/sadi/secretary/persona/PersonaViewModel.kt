package com.sadi.secretary.persona

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — PersonaViewModel.kt                ║
// ║       Phase 04 · Persona ViewModel                           ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PersonaUiState(
    val contacts: List<ContactEntity> = emptyList(),
    val selectedContact: ContactEntity? = null,
    val isLoading: Boolean = false,
    val toastMessage: String? = null
)

@HiltViewModel
class PersonaViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val personaEngine: PersonaEngine
) : ViewModel() {

    private val _uiState = MutableStateFlow(PersonaUiState())
    val uiState: StateFlow<PersonaUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllContacts().collect { contacts ->
                _uiState.update { it.copy(contacts = contacts) }
            }
        }
    }

    fun selectContact(contact: ContactEntity) {
        _uiState.update { it.copy(selectedContact = contact) }
    }

    fun updateRelation(contact: ContactEntity, relation: Relation) {
        val suggested = personaEngine.suggestPersona(contact.name)
        val updatedContact = contact.copy(
            relation = relation.name,
            pronoun  = relation.defaultPronoun,
            style    = relation.defaultStyle
        )
        saveContact(updatedContact, "${contact.name} এর relation update হলো ✅")
    }

    fun updatePronoun(contact: ContactEntity, pronoun: String) {
        saveContact(contact.copy(pronoun = pronoun), "Pronoun update হলো")
    }

    fun updateStyle(contact: ContactEntity, style: Style) {
        saveContact(contact.copy(style = style.name), "Style update হলো ✅")
    }

    fun updateAutoSend(contact: ContactEntity, enabled: Boolean) {
        val status = if (enabled) "চালু" else "বন্ধ"
        saveContact(
            contact.copy(autoSendEnabled = enabled),
            "${contact.name} এর auto-send $status হলো"
        )
    }

    fun updateDelay(contact: ContactEntity, delaySeconds: Int) {
        saveContact(
            contact.copy(replyDelaySeconds = delaySeconds),
            "Reply delay: ${delaySeconds}s set হলো"
        )
    }

    fun updateRestricted(contact: ContactEntity, restricted: Boolean) {
        val status = if (restricted) "restricted" else "unrestricted"
        saveContact(
            contact.copy(isRestricted = restricted),
            "${contact.name} $status করা হলো"
        )
    }

    private fun saveContact(contact: ContactEntity, toast: String) {
        viewModelScope.launch {
            repository.updateContact(contact)
            _uiState.update { it.copy(
                selectedContact = contact,
                toastMessage = toast
            )}
        }
    }

    fun clearToast() = _uiState.update { it.copy(toastMessage = null) }
}
