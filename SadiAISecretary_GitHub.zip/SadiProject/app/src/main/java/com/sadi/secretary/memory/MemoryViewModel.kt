package com.sadi.secretary.memory

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — MemoryViewModel.kt                ║
// ║        Phase 05 · Memory ViewModel                           ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.db.MemoryEntity
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MemoryUiState(
    val contactMemories: List<Pair<ContactEntity, MemoryEntity>> = emptyList(),
    val selectedContactId: Long? = null,
    val isLoading: Boolean = false
)

@HiltViewModel
class MemoryViewModel @Inject constructor(
    private val repository: MessageRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MemoryUiState())
    val uiState: StateFlow<MemoryUiState> = _uiState.asStateFlow()

    init {
        loadMemories()
    }

    private fun loadMemories() {
        viewModelScope.launch {
            repository.getAllContacts().collect { contacts ->
                val pairs = contacts.mapNotNull { contact ->
                    val memory = repository.getMemory(contact.id)
                    memory?.let { Pair(contact, it) }
                }
                _uiState.update { it.copy(contactMemories = pairs) }
            }
        }
    }

    fun selectContact(contactId: Long) {
        _uiState.update { it.copy(selectedContactId = contactId) }
    }

    // Memory manually clear করা (যদি দরকার হয়)
    fun clearMemory(contactId: Long) {
        viewModelScope.launch {
            repository.initMemoryIfNeeded(contactId)  // reset করে নতুন করে init
        }
    }
}
