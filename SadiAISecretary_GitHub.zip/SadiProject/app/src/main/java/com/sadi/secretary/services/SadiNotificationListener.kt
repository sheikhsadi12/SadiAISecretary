package com.sadi.secretary.services

// ╔══════════════════════════════════════════════════════════════╗
// ║      SADI AI SECRETARY — SadiNotificationListener.kt         ║
// ║      Phase 01 · Message Capture Engine                       ║
// ║                                                              ║
// ║  SUPPORTED:                                                  ║
// ║    → Messenger  (com.facebook.orca)                          ║
// ║    → Telegram   (org.telegram.messenger)                     ║
// ║                                                              ║
// ║  FLOW:                                                       ║
// ║    Notification আসলো → parse করো → DB তে save করো           ║
// ║    → ReplyEngine কে জানাও                                    ║
// ╚══════════════════════════════════════════════════════════════╝

import android.app.Notification
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.sadi.secretary.SadiApp
import com.sadi.secretary.data.db.MessageDao
import com.sadi.secretary.data.db.MessageEntity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class SadiNotificationListener : NotificationListenerService() {

    @Inject lateinit var messageDao: MessageDao
    @Inject lateinit var replyEngine: ReplyEngine

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        private const val TAG = "SadiMsgCapture"

        // ── App Package Names ──────────────────────────────────
        const val PKG_MESSENGER = "com.facebook.orca"
        const val PKG_TELEGRAM  = "org.telegram.messenger"

        // ── Messenger notification extras ─────────────────────
        // Facebook Messenger এর notification এ এই keys থাকে
        private const val EXTRA_TITLE   = "android.title"
        private const val EXTRA_TEXT    = "android.text"
        private const val EXTRA_SUBTEXT = "android.subText"
        private const val EXTRA_SUMMARY = "android.summaryText"

        // ── Skip keywords ──────────────────────────────────────
        // এই ধরনের system notification skip করব
        private val SKIP_TEXTS = setOf(
            "missed call", "voice call", "video call",
            "missed video", "is calling",
            "Photo", "Sticker", "GIF", "Voice message",
            "missed call", "incoming call"
        )
    }

    // ──────────────────────────────────────────────────────────
    // Service Connected
    // ──────────────────────────────────────────────────────────
    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d(TAG, "✅ Notification Listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.w(TAG, "⚠️ Notification Listener disconnected")
        // Auto reconnect চেষ্টা
        requestRebind(componentName)
    }

    // ──────────────────────────────────────────────────────────
    // Notification আসলে এখানে আসে
    // ──────────────────────────────────────────────────────────
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName

        // শুধু supported apps process করব
        if (pkg !in SadiApp.SUPPORTED_APPS) return

        // System/bot notifications skip
        if (sbn.isOngoing) return

        val extras = sbn.notification.extras ?: return

        // App অনুযায়ী parse করব
        val parsed = when (pkg) {
            PKG_MESSENGER -> parseMessenger(extras, sbn)
            PKG_TELEGRAM  -> parseTelegram(extras, sbn)
            else -> null
        } ?: return

        // Skip list check
        if (SKIP_TEXTS.any { parsed.messageText.contains(it, ignoreCase = true) }) {
            Log.d(TAG, "Skipped system notification: ${parsed.messageText}")
            return
        }

        // Empty message skip
        if (parsed.messageText.isBlank()) return

        Log.d(TAG, "📩 New message from ${parsed.senderName} [${parsed.senderApp}]: ${parsed.messageText}")

        // DB তে save করো + AI engine কে জানাও
        scope.launch {
            val id = messageDao.insert(parsed)
            Log.d(TAG, "Message saved to DB with id: $id")

            // Phase 2: AI Reply Engine কে trigger করো
            replyEngine.processMessage(parsed.copy(id = id))
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Future: track dismissed notifications
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    // ══════════════════════════════════════════════════════════
    // PARSERS — প্রতিটা app এর notification আলাদাভাবে parse
    // ══════════════════════════════════════════════════════════

    // ── Messenger Parser ──────────────────────────────────────
    // Messenger notification structure:
    //   title = sender name (personal) OR group name (group)
    //   text  = message content
    //   subText/summaryText = group এ sender name
    private fun parseMessenger(
        extras: Bundle,
        sbn: StatusBarNotification
    ): MessageEntity? {
        return try {
            val title   = extras.getCharSequence(EXTRA_TITLE)?.toString() ?: return null
            val text    = extras.getCharSequence(EXTRA_TEXT)?.toString() ?: return null
            val summary = extras.getCharSequence(EXTRA_SUMMARY)?.toString()

            // Group chat detect: summary text থাকলে group
            val isGroup = summary != null
            val senderName = if (isGroup) {
                // Group এ: "Sender Name" format থেকে নাম বের করো
                text.substringBefore(":").trim().takeIf { it.isNotBlank() } ?: title
            } else {
                title
            }
            val messageText = if (isGroup) {
                text.substringAfter(":").trim()
            } else {
                text
            }

            MessageEntity(
                senderName  = senderName,
                senderApp   = "messenger",
                messageText = messageText,
                isGroup     = isGroup,
                groupName   = if (isGroup) title else null,
                timestamp   = sbn.postTime,
                packageName = PKG_MESSENGER
            )
        } catch (e: Exception) {
            Log.e(TAG, "Messenger parse error: ${e.message}")
            null
        }
    }

    // ── Telegram Parser ───────────────────────────────────────
    // Telegram notification structure:
    //   title = contact/group name
    //   text  = message (personal) OR "Sender: message" (group)
    private fun parseTelegram(
        extras: Bundle,
        sbn: StatusBarNotification
    ): MessageEntity? {
        return try {
            val title = extras.getCharSequence(EXTRA_TITLE)?.toString() ?: return null
            val text  = extras.getCharSequence(EXTRA_TEXT)?.toString() ?: return null

            // Telegram group: "Name: message" format
            val isGroup = text.contains(": ") && !text.startsWith("@")

            val senderName: String
            val messageText: String

            if (isGroup) {
                senderName  = text.substringBefore(":").trim()
                messageText = text.substringAfter(":").trim()
            } else {
                senderName  = title
                messageText = text
            }

            // Telegram system messages skip
            if (messageText.startsWith("📷") ||
                messageText.startsWith("🎵") ||
                messageText.startsWith("📎") ||
                messageText == "Photo" ||
                messageText == "Sticker" ||
                messageText == "GIF") {
                return null
            }

            MessageEntity(
                senderName  = senderName,
                senderApp   = "telegram",
                messageText = messageText,
                isGroup     = isGroup,
                groupName   = if (isGroup) title else null,
                timestamp   = sbn.postTime,
                packageName = PKG_TELEGRAM
            )
        } catch (e: Exception) {
            Log.e(TAG, "Telegram parse error: ${e.message}")
            null
        }
    }
}
