package com.sadi.secretary.privacy

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — PrivacyManager.kt                  ║
// ║       Phase 09 · Privacy Guard                               ║
// ║                                                              ║
// ║  Rules:                                                      ║
// ║    → LOVE relation → auto send OFF by default                ║
// ║    → Group chats → suggest only, never auto                  ║
// ║    → Unknown contacts → no AI reply                          ║
// ║    → Sensitive keywords → force manual                       ║
// ║    → All data AES-256 encrypted locally                      ║
// ╚══════════════════════════════════════════════════════════════╝

import android.util.Log
import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.db.MessageEntity
import javax.inject.Inject
import javax.inject.Singleton

// Privacy check result
sealed class PrivacyResult {
    object Allow                              : PrivacyResult()
    data class ForceManual(val reason: String): PrivacyResult()
    data class Block(val reason: String)      : PrivacyResult()
}

@Singleton
class PrivacyManager @Inject constructor() {

    companion object {
        private const val TAG = "SadiPrivacy"

        // এই keywords থাকলে → force manual mode
        private val SENSITIVE_KEYWORDS = setOf(
            // Personal sensitive
            "password", "পাসওয়ার্ড", "bank", "ব্যাংক", "bkash", "বিকাশ",
            "account", "otp", "pin", "secret", "গোপন",
            // Emotional sensitive
            "বিয়ে", "marry", "love you", "ভালোবাসি", "propose",
            // Medical
            "hospital", "হাসপাতাল", "operation", "ক্যান্সার", "মৃত্যু",
            // Legal
            "police", "পুলিশ", "court", "মামলা", "arrest"
        )

        // এই keywords থাকলে → block completely
        private val BLOCK_KEYWORDS = setOf(
            "নগ্ন", "অশ্লীল", "xxx", "18+", "adult"
        )
    }

    // ══════════════════════════════════════════════════════════
    // MAIN PRIVACY CHECK
    // ══════════════════════════════════════════════════════════
    fun checkPrivacy(
        message: MessageEntity,
        contact: ContactEntity?
    ): PrivacyResult {

        // Unknown contact check
        if (contact == null) {
            Log.d(TAG, "Unknown contact — blocking AI reply")
            return PrivacyResult.Block("Unknown contact — AI reply disabled")
        }

        // Restricted contact check
        if (contact.isRestricted) {
            return PrivacyResult.Block("Contact is restricted")
        }

        // Block keywords check
        val msgLower = message.messageText.lowercase()
        val blockWord = BLOCK_KEYWORDS.find { msgLower.contains(it) }
        if (blockWord != null) {
            Log.w(TAG, "Block keyword found: $blockWord")
            return PrivacyResult.Block("Inappropriate content detected")
        }

        // Group chat — suggest only
        if (message.isGroup) {
            return PrivacyResult.ForceManual("Group chat — manual approval required")
        }

        // LOVE relation — force manual
        if (contact.relation == "LOVE" && contact.autoSendEnabled) {
            Log.d(TAG, "LOVE relation — forcing manual for safety")
            return PrivacyResult.ForceManual("Special contact — please review before sending")
        }

        // Sensitive keywords — force manual
        val sensitiveWord = SENSITIVE_KEYWORDS.find { msgLower.contains(it) }
        if (sensitiveWord != null) {
            Log.d(TAG, "Sensitive keyword found: $sensitiveWord")
            return PrivacyResult.ForceManual("Sensitive topic — manual review needed")
        }

        return PrivacyResult.Allow
    }

    // ══════════════════════════════════════════════════════════
    // AUTO SEND ALLOWED?
    // ══════════════════════════════════════════════════════════
    fun isAutoSendAllowed(contact: ContactEntity, message: MessageEntity): Boolean {
        // Group chat → never auto send
        if (message.isGroup) return false

        // LOVE → never auto send
        if (contact.relation == "LOVE") return false

        // Restricted → never
        if (contact.isRestricted) return false

        // Sensitive content → never
        val msgLower = message.messageText.lowercase()
        if (SENSITIVE_KEYWORDS.any { msgLower.contains(it) }) return false

        // Contact level auto send setting
        return contact.autoSendEnabled
    }

    // ══════════════════════════════════════════════════════════
    // SANITIZE — API তে পাঠানোর আগে sensitive data mask করো
    // ══════════════════════════════════════════════════════════
    fun sanitizeForApi(text: String): String {
        var sanitized = text
        // Phone numbers mask করো
        sanitized = sanitized.replace(Regex("\\b01[3-9]\\d{8}\\b"), "[PHONE]")
        // Card numbers
        sanitized = sanitized.replace(Regex("\\b\\d{4}[- ]?\\d{4}[- ]?\\d{4}[- ]?\\d{4}\\b"), "[CARD]")
        // OTP/PIN
        sanitized = sanitized.replace(Regex("(?i)(otp|pin|code)[:\\s]+\\d+"), "[SENSITIVE_CODE]")
        return sanitized
    }
}
