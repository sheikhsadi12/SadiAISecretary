package com.sadi.secretary.ui.control

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — ControlViewModel.kt                ║
// ║       Phase 03 · Control Layer ViewModel                     ║
// ║                                                              ║
// ║  Pending replies manage করে                                  ║
// ║  Send / Edit / Reject actions handle করে                     ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.db.ReplyQueueEntity
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// UI State
data class ControlUiState(
    val pendingReplies: List<ReplyQueueEntity> = emptyList(),
    val pendingCount: Int = 0,
    val isLoading: Boolean = false,
    val toastMessage: String? = null
)

@HiltViewModel
class ControlViewModel @Inject constructor(
    private val repository: MessageRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ControlUiState())
    val uiState: StateFlow<ControlUiState> = _uiState.asStateFlow()

    init {
        // Pending replies observe করা (real-time)
        viewModelScope.launch {
            repository.getPendingReplies().collect { replies ->
                _uiState.update { it.copy(pendingReplies = replies) }
            }
        }
        // Count observe করা
        viewModelScope.launch {
            repository.getPendingCount().collect { count ->
                _uiState.update { it.copy(pendingCount = count) }
            }
        }
    }

    // ── ✅ APPROVE (Send) ──────────────────────────────────────
    fun approveReply(queueId: Long) {
        viewModelScope.launch {
            repository.approveReply(queueId)
            showToast("Reply approved — sending shortly ✅")
            // Phase 8: AutoSendEngine এখানে trigger হবে
        }
    }

    // ── ✏️ EDIT ────────────────────────────────────────────────
    fun editReply(queueId: Long, newText: String) {
        viewModelScope.launch {
            if (newText.isBlank()) {
                showToast("Reply empty হতে পারবে না!")
                return@launch
            }
            repository.editReply(queueId, newText)
            repository.approveReply(queueId)
            showToast("Reply edited and approved ✏️")
        }
    }

    // ── ❌ REJECT ──────────────────────────────────────────────
    fun rejectReply(queueId: Long) {
        viewModelScope.launch {
            repository.rejectReply(queueId)
            showToast("Reply rejected ❌")
        }
    }

    // ── Contact auto-send toggle ───────────────────────────────
    fun toggleAutoSend(contact: ContactEntity) {
        viewModelScope.launch {
            repository.updateContact(
                contact.copy(autoSendEnabled = !contact.autoSendEnabled)
            )
            val status = if (!contact.autoSendEnabled) "চালু" else "বন্ধ"
            showToast("${contact.name} এর auto-send $status হলো")
        }
    }

    private fun showToast(msg: String) {
        _uiState.update { it.copy(toastMessage = msg) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
