package com.sadi.secretary.services

// ╔══════════════════════════════════════════════════════════════╗
// ║         SADI AI SECRETARY — ReplyEngine.kt                   ║
// ║         Phase 02 · Full AI Reply Engine                      ║
// ║                                                              ║
// ║  FLOW:                                                       ║
// ║    Message → Contact load → Memory load → Emotion detect     ║
// ║    → Prompt build → AI call → Queue তে save → Notify         ║
// ╚══════════════════════════════════════════════════════════════╝

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import com.sadi.secretary.R
import com.sadi.secretary.SadiApp
import com.sadi.secretary.ai.*
import com.sadi.secretary.data.db.MessageEntity
import com.sadi.secretary.data.db.ReplyQueueEntity
import com.sadi.secretary.data.repository.MessageRepository
import com.sadi.secretary.ui.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReplyEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: MessageRepository,
    private val promptBuilder: PromptBuilder,
    private val clientFactory: AiClientFactory
) {
    companion object {
        private const val TAG = "SadiReplyEngine"
    }

    // ══════════════════════════════════════════════════════════
    // MAIN ENTRY — Message আসলে এখানে আসে
    // ══════════════════════════════════════════════════════════
    suspend fun processMessage(message: MessageEntity) {
        try {
            Log.d(TAG, "Processing message from: ${message.senderName}")

            // Group chat এ AI reply করবে না (Phase 3 এ setting হবে)
            if (message.isGroup) {
                Log.d(TAG, "Group message — skipping for now")
                return
            }

            // ── Step 1: Contact load / create ─────────────────
            val contact = repository.getOrCreateContact(
                name = message.senderName,
                app  = message.senderApp
            )

            // Restricted contact check
            if (contact.isRestricted) {
                Log.d(TAG, "Contact ${contact.name} is restricted — no AI reply")
                return
            }

            // ── Step 2: Memory load ────────────────────────────
            repository.initMemoryIfNeeded(contact.id)
            val memory = repository.getMemory(contact.id)

            // ── Step 3: Recent messages (context) ─────────────
            val recentMessages = repository.getRecentMessages(message.senderName)

            // ── Step 4: Emotion detect ─────────────────────────
            val emotion = detectEmotion(message.messageText)
            repository.updateEmotion(message.id, emotion)
            repository.updateEmotion(contact.id, emotion)
            Log.d(TAG, "Detected emotion: $emotion")

            // ── Step 5: Build prompt ───────────────────────────
            val systemPrompt = promptBuilder.buildSystemPrompt(
                contact        = contact,
                memory         = memory,
                recentMessages = recentMessages
            )

            // ── Step 6: AI call ────────────────────────────────
            val request = AiRequest(
                systemPrompt = systemPrompt,
                messages = listOf(
                    AiMessage(role = "user", content = message.messageText)
                ),
                maxTokens   = 200,
                temperature = 0.85
            )

            val client = clientFactory.getActiveClient()
            Log.d(TAG, "Using AI provider: ${client.provider.displayName}")

            val response = client.generate(request)

            if (!response.isSuccess || response.text.isBlank()) {
                Log.e(TAG, "AI generation failed: ${response.error}")
                return
            }

            Log.d(TAG, "AI Reply: ${response.text}")

            // ── Step 7: Queue তে save ──────────────────────────
            val queueItem = ReplyQueueEntity(
                messageId       = message.id,
                contactName     = message.senderName,
                contactApp      = message.senderApp,
                originalMessage = message.messageText,
                aiReply         = response.text,
                scheduledSendAt = System.currentTimeMillis() + (contact.replyDelaySeconds * 1000L)
            )
            val queueId = repository.addToQueue(queueItem)

            // Auto-send enabled হলে APPROVED করে দাও
            if (contact.autoSendEnabled) {
                repository.approveReply(queueId)
                Log.d(TAG, "Auto-send enabled — reply approved automatically")
            }

            // ── Step 8: User কে notify করো ────────────────────
            showReplyNotification(
                queueId         = queueId,
                senderName      = message.senderName,
                originalMessage = message.messageText,
                aiReply         = response.text
            )

            // ── Step 9: Memory summary (প্রতি ৫ message এ) ────
            val updatedMemory = repository.getMemory(contact.id)
            val msgCount = (updatedMemory?.messageCount ?: 0) + 1
            if (msgCount % 5 == 0) {
                generateAndSaveSummary(contact.id, message.senderName, msgCount)
            }

        } catch (e: Exception) {
            Log.e(TAG, "ReplyEngine error: ${e.message}", e)
        }
    }

    // ══════════════════════════════════════════════════════════
    // EMOTION DETECTION
    // ══════════════════════════════════════════════════════════
    private suspend fun detectEmotion(text: String): String {
        return try {
            val client = clientFactory.getActiveClient()
            val response = client.generate(
                AiRequest(
                    systemPrompt = "You detect emotions in messages. Reply with ONLY one word.",
                    messages = listOf(
                        AiMessage("user", promptBuilder.buildEmotionPrompt(text))
                    ),
                    maxTokens   = 10,
                    temperature = 0.1
                )
            )
            val emotion = response.text.trim().uppercase()
            if (emotion in listOf("HAPPY", "SAD", "ANGRY", "URGENT")) emotion else "NEUTRAL"
        } catch (e: Exception) {
            "NEUTRAL"
        }
    }

    // ══════════════════════════════════════════════════════════
    // CONVERSATION SUMMARY
    // ══════════════════════════════════════════════════════════
    private suspend fun generateAndSaveSummary(
        contactId: Long,
        contactName: String,
        count: Int
    ) {
        try {
            val messages = repository.getRecentMessages(contactName)
            if (messages.isEmpty()) return

            val client = clientFactory.getActiveClient()
            val response = client.generate(
                AiRequest(
                    systemPrompt = "Summarize conversations briefly in Bangla.",
                    messages = listOf(
                        AiMessage("user", promptBuilder.buildSummaryPrompt(messages, contactName))
                    ),
                    maxTokens   = 150,
                    temperature = 0.5
                )
            )
            if (response.isSuccess) {
                repository.updateSummary(contactId, response.text, count)
                Log.d(TAG, "Summary updated for contact $contactId")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Summary generation failed: ${e.message}")
        }
    }

    // ══════════════════════════════════════════════════════════
    // NOTIFICATION — Reply ready হলে user কে জানাও
    // ══════════════════════════════════════════════════════════
    private fun showReplyNotification(
        queueId: Long,
        senderName: String,
        originalMessage: String,
        aiReply: String
    ) {
        val openIntent = PendingIntent.getActivity(
            context, queueId.toInt(),
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, SadiApp.CHANNEL_REPLY)
            .setContentTitle("📩 $senderName এর reply ready")
            .setContentText(aiReply)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("\"$originalMessage\"\n\n➤ $aiReply")
            )
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(queueId.toInt() + 2000, notification)
    }
}
