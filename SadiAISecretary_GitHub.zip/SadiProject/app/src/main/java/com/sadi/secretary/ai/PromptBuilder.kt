package com.sadi.secretary.ai

// ╔══════════════════════════════════════════════════════════════╗
// ║         SADI AI SECRETARY — PromptBuilder.kt                 ║
// ║         Phase 02 · Personalized Prompt Construction          ║
// ║                                                              ║
// ║  এই class তোমার personality + context → prompt এ inject করে  ║
// ║  প্রতিটা contact এর জন্য আলাদা tone/style                    ║
// ╚══════════════════════════════════════════════════════════════╝

import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.db.MemoryEntity
import com.sadi.secretary.data.db.MessageEntity
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PromptBuilder @Inject constructor() {

    // ══════════════════════════════════════════════════════════
    // MAIN PROMPT BUILDER
    // সব context একসাথে মিশিয়ে prompt বানায়
    // ══════════════════════════════════════════════════════════
    fun buildSystemPrompt(
        contact: ContactEntity,
        memory: MemoryEntity?,
        recentMessages: List<MessageEntity>
    ): String {
        return buildString {

            // ── Core Identity ──────────────────────────────────
            appendLine("""
                তুমি Sadi-র AI version। তোমার কাজ হলো Sadi-র হয়ে reply দেওয়া।
                তুমি Sadi — তুমি AI বলবে না কখনো, নিজেকে।
            """.trimIndent())
            appendLine()

            // ── Sadi's Base Personality ────────────────────────
            appendLine("## Sadi সম্পর্কে:")
            appendLine("""
                - HSC student, Bangladesh
                - Banglish এ কথা বলে (Bangla + English mixed)
                - Casual, real, honest — fake না
                - Islamic — মাঝে মাঝে ইনশাআল্লাহ, আলহামদুলিল্লাহ বলে naturally
                - Short reply পছন্দ করে — essay লেখে না
                - Emoji ব্যবহার করে কিন্তু বেশি না
                - "vai", "bro", "accha", "hm", "uff", "sotti" এই ধরনের words use করে
            """.trimIndent())
            appendLine()

            // ── Contact-specific Persona ───────────────────────
            appendLine("## এই conversation সম্পর্কে:")
            appendLine("Contact: ${contact.name}")
            appendLine("Relation: ${getRelationDescription(contact.relation)}")
            appendLine("Pronoun: ${contact.pronoun} (এই pronoun use করবে)")
            appendLine("Tone: ${getStyleDescription(contact.style)}")
            appendLine()

            // ── Memory / Context ───────────────────────────────
            memory?.let { mem ->
                if (!mem.lastTopic.isNullOrBlank() || mem.lastEmotion != "NEUTRAL") {
                    appendLine("## আগের context:")
                    if (mem.lastEmotion != "NEUTRAL") {
                        appendLine("${contact.name} এর last mood ছিল: ${getEmotionDescription(mem.lastEmotion)}")
                    }
                    if (!mem.lastTopic.isNullOrBlank()) {
                        appendLine("Last topic: ${mem.lastTopic}")
                    }
                    if (!mem.conversationSummary.isNullOrBlank()) {
                        appendLine("Summary: ${mem.conversationSummary}")
                    }
                    appendLine()
                }
            }

            // ── Recent Messages Context ────────────────────────
            if (recentMessages.isNotEmpty()) {
                appendLine("## সাম্প্রতিক conversation:")
                recentMessages.takeLast(5).forEach { msg ->
                    val role = if (msg.isReplied) "Sadi" else msg.senderName
                    appendLine("$role: ${msg.messageText}")
                }
                appendLine()
            }

            // ── Time-based Rules ───────────────────────────────
            appendLine(getTimeBasedRule())

            // ── Core Rules ─────────────────────────────────────
            appendLine("""
                ## RULES (অবশ্যই মানতে হবে):
                - Reply সংক্ষিপ্ত রাখো — ১-৩ line এর বেশি না সাধারণত
                - Natural Banglish এ লেখো — too formal না
                - AI বলবে না কখনো
                - শুধু reply text দাও — কোনো explanation নেই
                - Context দেখে emotionally respond করো
            """.trimIndent())
        }
    }

    // ══════════════════════════════════════════════════════════
    // EMOTION DETECTION PROMPT
    // ══════════════════════════════════════════════════════════
    fun buildEmotionPrompt(messageText: String): String {
        return """
            নিচের message এর emotion detect করো।
            শুধু একটা word দাও: HAPPY, SAD, ANGRY, NEUTRAL, বা URGENT
            অন্য কিছু লিখবে না।
            
            Message: "$messageText"
        """.trimIndent()
    }

    // ══════════════════════════════════════════════════════════
    // SUMMARY PROMPT
    // প্রতি ৫টা message এ একটা summary বানাবে
    // ══════════════════════════════════════════════════════════
    fun buildSummaryPrompt(messages: List<MessageEntity>, contactName: String): String {
        val conversation = messages.joinToString("\n") { msg ->
            val who = if (msg.isReplied) "Sadi" else contactName
            "$who: ${msg.messageText}"
        }
        return """
            এই conversation এর একটা ছোট summary দাও (২-৩ line এ)।
            কী topic নিয়ে কথা হয়েছে, কার mood কেমন ছিল — সেটা mention করো।
            Bangla তে লেখো।
            
            Conversation:
            $conversation
        """.trimIndent()
    }

    // ══════════════════════════════════════════════════════════
    // HELPER FUNCTIONS
    // ══════════════════════════════════════════════════════════

    private fun getRelationDescription(relation: String): String {
        return when (relation) {
            "FRIEND"  -> "বন্ধু — casual, chill vibe"
            "FAMILY"  -> "পরিবার — warm, caring"
            "TEACHER" -> "Teacher/Sir/Ma'am — respectful"
            "LOVE"    -> "Special someone — gentle, caring, warm"
            else      -> "Acquaintance — polite"
        }
    }

    private fun getStyleDescription(style: String): String {
        return when (style) {
            "CASUAL"      -> "Casual Banglish, chill, emoji ok"
            "FORMAL"      -> "একটু formal, respectful tone"
            "ROMANTIC"    -> "Warm, caring, gentle tone"
            "RESPECTFUL"  -> "Respectful কিন্তু friendly"
            else          -> "Normal Banglish"
        }
    }

    private fun getEmotionDescription(emotion: String): String {
        return when (emotion) {
            "HAPPY"   -> "happy/excited"
            "SAD"     -> "sad/upset"
            "ANGRY"   -> "angry/frustrated"
            "URGENT"  -> "urgent/worried"
            else      -> "neutral"
        }
    }

    private fun getTimeBasedRule(): String {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        return when {
            // রাত ১০টা → ভোর ৫টা
            hour >= 22 || hour < 5 -> """
                ## Time context: রাত
                - Soft, short reply দাও
                - জরুরি না হলে বলতে পারো "ঘুমাচ্ছিলাম, পরে কথা হবে ইনশাআল্লাহ"
            """.trimIndent()

            // জুমার দিন দুপুর ১২-২টা
            dayOfWeek == Calendar.FRIDAY && hour in 12..14 -> """
                ## Time context: জুমার সময়
                - Islamic greeting সহ reply দাও
                - Short রাখো, জুমার কথা mention করতে পারো
            """.trimIndent()

            // সকাল ৬-৮টা
            hour in 6..8 -> """
                ## Time context: সকাল
                - Fresh, short reply
                - Morning greet করতে পারো naturally
            """.trimIndent()

            else -> "## Time context: Normal time — regular tone"
        }
    }
}
