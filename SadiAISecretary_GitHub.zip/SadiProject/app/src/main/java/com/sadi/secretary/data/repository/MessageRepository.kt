package com.sadi.secretary.data.repository

import com.sadi.secretary.data.db.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessageRepository @Inject constructor(
    private val messageDao: MessageDao,
    private val contactDao: ContactDao,
    private val memoryDao: MemoryDao,
    private val replyQueueDao: ReplyQueueDao
) {
    // ── Messages ───────────────────────────────────────────────
    fun getAllMessages(): Flow<List<MessageEntity>> = messageDao.getAllMessages()
    fun getUnrepliedMessages(): Flow<List<MessageEntity>> = messageDao.getUnrepliedMessages()
    suspend fun saveMessage(message: MessageEntity): Long = messageDao.insert(message)
    suspend fun markReplied(id: Long) = messageDao.markAsReplied(id)
    suspend fun updateEmotion(id: Long, emotion: String) = messageDao.updateEmotion(id, emotion)
    suspend fun getRecentMessages(senderName: String): List<MessageEntity> = messageDao.getMessagesBySender(senderName)

    // Sadi এর sent messages (Style Analyzer এর জন্য)
    suspend fun getSadiSentMessages(): List<MessageEntity> = messageDao.getRepliedMessages()

    // ── Contacts ──────────────────────────────────────────────
    fun getAllContacts(): Flow<List<ContactEntity>> = contactDao.getAllContacts()
    suspend fun getContact(name: String, app: String): ContactEntity? = contactDao.getContact(name, app)
    suspend fun saveContact(contact: ContactEntity): Long = contactDao.insert(contact)
    suspend fun updateContact(contact: ContactEntity) = contactDao.update(contact)

    suspend fun getOrCreateContact(name: String, app: String): ContactEntity {
        return contactDao.getContact(name, app) ?: run {
            val newContact = ContactEntity(
                name     = name,
                app      = app,
                senderId = "${app}_${name.lowercase().replace(" ", "_")}"
            )
            val id = contactDao.insert(newContact)
            newContact.copy(id = id)
        }
    }

    // ── Memory ────────────────────────────────────────────────
    suspend fun getMemory(contactId: Long): MemoryEntity? = memoryDao.getMemory(contactId)
    suspend fun updateEmotion(contactId: Long, emotion: String) = memoryDao.updateEmotion(contactId, emotion)
    suspend fun updateSummary(contactId: Long, summary: String, count: Int) = memoryDao.updateSummary(contactId, summary, count)
    suspend fun saveMemoryDirectly(memory: MemoryEntity) = memoryDao.insertOrUpdate(memory)

    suspend fun initMemoryIfNeeded(contactId: Long) {
        if (memoryDao.getMemory(contactId) == null) {
            memoryDao.insertOrUpdate(MemoryEntity(contactId = contactId))
        }
    }

    // ── Reply Queue ───────────────────────────────────────────
    fun getPendingReplies(): Flow<List<ReplyQueueEntity>> = replyQueueDao.getPendingReplies()
    fun getPendingCount(): Flow<Int> = replyQueueDao.getPendingCount()
    suspend fun addToQueue(reply: ReplyQueueEntity): Long = replyQueueDao.insert(reply)
    suspend fun approveReply(id: Long) = replyQueueDao.updateStatus(id, "APPROVED")
    suspend fun rejectReply(id: Long) = replyQueueDao.updateStatus(id, "REJECTED")
    suspend fun markSent(id: Long) = replyQueueDao.updateStatus(id, "SENT")
    suspend fun editReply(id: Long, newReply: String) = replyQueueDao.updateReply(id, newReply)
    suspend fun getApprovedReplies(): List<ReplyQueueEntity> = replyQueueDao.getApprovedReplies()

    suspend fun cleanOldData() {
        val sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000)
        messageDao.deleteOldMessages(sevenDaysAgo)
        replyQueueDao.cleanOld(sevenDaysAgo)
    }
}
