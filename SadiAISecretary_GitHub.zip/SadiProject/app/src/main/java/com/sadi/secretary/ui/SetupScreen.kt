package com.sadi.secretary.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SetupScreen(
    onNotifClick: () -> Unit,
    onAccessClick: () -> Unit,
    notifOk: Boolean,
    accessOk: Boolean
) {
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))
            Text("🤖", fontSize = 56.sp)
            Spacer(Modifier.height(16.dp))
            Text("Sadi AI Secretary", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Digital You System", fontSize = 14.sp, color = Color(0xFF64748B), modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(40.dp))
            Text("প্রথমে এই ২টা permission দাও", fontSize = 16.sp, color = Color(0xFF94A3B8))
            Spacer(Modifier.height(20.dp))

            PermCard("১", "Notification Access", "Messenger + Telegram message ধরতে", notifOk, onNotifClick)
            Spacer(Modifier.height(12.dp))
            PermCard("২", "Accessibility Access", "Auto reply send করতে", accessOk, onAccessClick)

            Spacer(Modifier.height(24.dp))
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1200))) {
                Column(Modifier.padding(14.dp)) {
                    Text("⚠️ Redmi / MIUI Users", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCD34D))
                    Spacer(Modifier.height(6.dp))
                    Text("Settings → Apps → Sadi Secretary\n✅ Autostart → ON\n✅ Battery Saver → No restrictions",
                        fontSize = 12.sp, color = Color(0xFF92781A), lineHeight = 20.sp)
                }
            }

            if (notifOk && accessOk) {
                Spacer(Modifier.height(20.dp))
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A2018))) {
                    Text("✅ সব ready! Sadi AI চলছে 🟢", fontSize = 15.sp, fontWeight = FontWeight.Bold,
                        color = Color(0xFF34D399), modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun PermCard(step: String, title: String, desc: String, granted: Boolean, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(40.dp).background(
                if (granted) Color(0xFF0A2018) else Color(0xFF0D1422), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center) {
                Text(if (granted) "✅" else step, fontSize = if (granted) 18.sp else 16.sp,
                    fontWeight = FontWeight.Bold, color = if (granted) Color(0xFF34D399) else Color(0xFF00D4FF))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(desc, fontSize = 12.sp, color = Color(0xFF64748B), modifier = Modifier.padding(top = 2.dp))
            }
            if (!granted) {
                TextButton(onClick = onClick, colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF00D4FF))) {
                    Text("দাও →", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
