package com.sadi.secretary.style

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — StyleScreen.kt                    ║
// ║        Phase 06 · Style Settings UI                          ║
// ║                                                              ║
// ║  তোমার writing style দেখাবে + manually adjust করতে দেবে     ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun StyleScreen(
    viewModel: StyleViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val config = uiState.styleConfig
    val scrollState = rememberScrollState()

    uiState.toastMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2000)
            viewModel.clearToast()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {

        Column(modifier = Modifier.fillMaxSize().verticalScroll(scrollState)) {

            // ── Header ─────────────────────────────────────────
            Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Style Imitation ✍️", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("AI তোমার মতো লিখবে — এখানে tune করো", fontSize = 12.sp, color = Color(0xFF64748B))
                        }
                        // Re-analyze button
                        TextButton(onClick = { viewModel.reAnalyze() }) {
                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp), tint = Color(0xFF00D4FF))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Re-analyze", color = Color(0xFF00D4FF), fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── Detected Style Summary ─────────────────────────
            StyleSummaryCard(config = config)

            Spacer(modifier = Modifier.height(16.dp))

            // ── Emoji Frequency ────────────────────────────────
            SectionLabel("EMOJI FREQUENCY")
            SegmentedSelector(
                options  = EmojiFreq.values().toList(),
                selected = config.emojiFrequency,
                onSelect = { viewModel.setEmojiFreq(it) },
                label    = { it.displayName },
                activeColor = Color(0xFFFCD34D)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Sentence Length ────────────────────────────────
            SectionLabel("SENTENCE LENGTH")
            SegmentedSelector(
                options  = SentenceStyle.values().toList(),
                selected = config.sentenceStyle,
                onSelect = { viewModel.setSentenceStyle(it) },
                label    = { it.displayName },
                activeColor = Color(0xFF00D4FF)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Punctuation ────────────────────────────────────
            SectionLabel("PUNCTUATION STYLE")
            SegmentedSelector(
                options  = PuncStyle.values().toList(),
                selected = config.punctuationStyle,
                onSelect = { viewModel.setPuncStyle(it) },
                label    = { it.displayName },
                activeColor = Color(0xFF7C3AED)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Slang Words ────────────────────────────────────
            SectionLabel("তোমার SLANG WORDS")
            SlangEditor(
                slangList = config.usesSlang,
                onAdd     = { viewModel.addSlang(it) },
                onRemove  = { viewModel.removeSlang(it) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Style Preview ──────────────────────────────────
            SectionLabel("PREVIEW — AI এভাবে লিখবে")
            StylePreviewCard(config = config)

            Spacer(modifier = Modifier.height(40.dp))
        }

        // Toast
        uiState.toastMessage?.let { msg ->
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF1E2D45)
            ) {
                Text(msg, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp), color = Color(0xFF00D4FF), fontSize = 13.sp)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// STYLE SUMMARY CARD
// ══════════════════════════════════════════════════════════════
@Composable
private fun StyleSummaryCard(config: StyleConfig) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Detected Style", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatChip(label = "Words/msg", value = "~${config.avgWordCount.toInt()}", color = Color(0xFF00D4FF))
                StatChip(label = "Emoji", value = config.emojiFrequency.displayName, color = Color(0xFFFCD34D))
                StatChip(label = "Style", value = config.sentenceStyle.displayName, color = Color(0xFF7C3AED))
            }
            Spacer(modifier = Modifier.height(8.dp))
            val banglaPercent = (config.banglaRatio * 100).toInt()
            Text(
                "Language mix: ~${banglaPercent}% Bangla · ~${100 - banglaPercent}% English",
                fontSize = 12.sp, color = Color(0xFF64748B)
            )
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, color: Color) {
    Surface(shape = RoundedCornerShape(8.dp), color = color.copy(alpha = 0.1f), border = BorderStroke(1.dp, color.copy(alpha = 0.3f))) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, fontSize = 10.sp, color = Color(0xFF475569))
        }
    }
}

// ══════════════════════════════════════════════════════════════
// SEGMENTED SELECTOR
// ══════════════════════════════════════════════════════════════
@Composable
private fun <T> SegmentedSelector(
    options: List<T>,
    selected: T,
    onSelect: (T) -> Unit,
    label: (T) -> String,
    activeColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            FilterChip(
                selected = isSelected,
                onClick  = { onSelect(option) },
                label    = { Text(label(option), fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                colors   = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = activeColor.copy(alpha = 0.15f),
                    selectedLabelColor     = activeColor,
                    containerColor         = Color(0xFF111827),
                    labelColor             = Color(0xFF64748B)
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true, selected = isSelected,
                    selectedBorderColor = activeColor,
                    borderColor = Color(0xFF1E2D45)
                )
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════
// SLANG EDITOR
// ══════════════════════════════════════════════════════════════
@Composable
private fun SlangEditor(
    slangList: List<String>,
    onAdd: (String) -> Unit,
    onRemove: (String) -> Unit
) {
    var newSlang by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        // Existing slang chips
        FlowRow(slangList, onRemove)

        Spacer(modifier = Modifier.height(10.dp))

        // Add new slang
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newSlang,
                onValueChange = { newSlang = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("নতুন word add করো...", color = Color(0xFF334155), fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00D4FF),
                    unfocusedBorderColor = Color(0xFF1E2D45),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color(0xFF94A3B8)
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (newSlang.isNotBlank()) {
                        onAdd(newSlang.trim())
                        newSlang = ""
                    }
                },
                modifier = Modifier.background(Color(0xFF0A1628), RoundedCornerShape(10.dp))
            ) {
                Icon(Icons.Default.Add, null, tint = Color(0xFF00D4FF))
            }
        }
    }
}

@Composable
private fun FlowRow(slangList: List<String>, onRemove: (String) -> Unit) {
    // Simple wrapping chips
    var rowList = slangList.chunked(4)
    rowList.forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 6.dp)) {
            row.forEach { word ->
                InputChip(
                    selected = false,
                    onClick  = {},
                    label    = { Text(word, fontSize = 12.sp) },
                    trailingIcon = {
                        Icon(Icons.Default.Close, null, modifier = Modifier.size(14.dp).clickable { onRemove(word) }, tint = Color(0xFF64748B))
                    },
                    colors = InputChipDefaults.inputChipColors(
                        containerColor = Color(0xFF111827),
                        labelColor     = Color(0xFF94A3B8)
                    ),
                    border = InputChipDefaults.inputChipBorder(
                        enabled = true, selected = false,
                        borderColor = Color(0xFF1E2D45)
                    )
                )
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// STYLE PREVIEW
// ══════════════════════════════════════════════════════════════
@Composable
private fun StylePreviewCard(config: StyleConfig) {
    val previewReplies = generatePreviewReplies(config)

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
        border = BorderStroke(1.dp, Color(0xFF1E3A5F))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                "Example replies তোমার current style এ:",
                fontSize = 12.sp,
                color = Color(0xFF7DD3FC),
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(10.dp))
            previewReplies.forEach { reply ->
                Row(modifier = Modifier.padding(vertical = 3.dp)) {
                    Text("→ ", fontSize = 13.sp, color = Color(0xFF00D4FF))
                    Text(reply, fontSize = 13.sp, color = Color(0xFF94A3B8))
                }
            }
        }
    }
}

private fun generatePreviewReplies(config: StyleConfig): List<String> {
    val emoji = when (config.emojiFrequency) {
        EmojiFreq.NONE   -> ""
        EmojiFreq.LOW    -> " 👍"
        EmojiFreq.MEDIUM -> " 😊"
        EmojiFreq.HIGH   -> " 🔥😄"
    }
    val ellipsis = if (config.usesEllipsis) "..." else ""
    val slang = config.usesSlang.firstOrNull() ?: "accha"

    return listOf(
        "$slang, thik ache$emoji",
        "hm$ellipsis dekhi ki hoy$emoji",
        "ইনশাআল্লাহ হবে$emoji"
    )
}

// Helper
@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        fontSize = 10.sp,
        color = Color(0xFF64748B),
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}
