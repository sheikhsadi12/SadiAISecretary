package com.sadi.secretary.receivers

// ╔══════════════════════════════════════════════════════════════╗
// ║           SADI AI SECRETARY — BootReceiver.kt                ║
// ║           Phase 00 · Auto Start on Boot                      ║
// ║                                                              ║
// ║  Phone restart হলেও Sadi AI auto start হবে                   ║
// ║  Xiaomi/MIUI এর special boot action ও handle করা হয়েছে      ║
// ╚══════════════════════════════════════════════════════════════╝

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.sadi.secretary.services.SadiForegroundService

class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "SadiBootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {

        val action = intent.action
        Log.d(TAG, "Boot action received: $action")

        // সব ধরনের boot action handle করা
        // Normal Android + Xiaomi MIUI দুটোর জন্যই
        val isBootAction = action in listOf(
            Intent.ACTION_BOOT_COMPLETED,                     // Standard Android
            "android.intent.action.QUICKBOOT_POWERON",        // HTC/Xiaomi
            "com.htc.intent.action.QUICKBOOT_POWERON"         // HTC
        )

        if (isBootAction) {
            Log.d(TAG, "Phone booted — starting Sadi AI Secretary...")
            startForegroundService(context)
        }
    }

    // ──────────────────────────────────────────────────────────
    // Foreground Service start করা
    // Android 8+ এ startForegroundService() use করতে হয়
    // ──────────────────────────────────────────────────────────
    private fun startForegroundService(context: Context) {
        try {
            val serviceIntent = Intent(context, SadiForegroundService::class.java).apply {
                action = SadiForegroundService.ACTION_START
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }

            Log.d(TAG, "Sadi Foreground Service started successfully after boot")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start service after boot: ${e.message}")
        }
    }
}
