package com.sadi.secretary.style

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — StyleManager.kt                   ║
// ║        Phase 06 · Style Config Manager                       ║
// ║                                                              ║
// ║  StyleConfig save/load করে                                   ║
// ║  Auto re-analyze করে (প্রতি ৫০ message এ)                    ║
// ╚══════════════════════════════════════════════════════════════╝

import android.content.Context
import android.util.Log
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.styleDataStore by preferencesDataStore(name = "sadi_style")

@Singleton
class StyleManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val styleAnalyzer: StyleAnalyzer,
    private val repository: MessageRepository
) {
    companion object {
        private const val TAG = "SadiStyleManager"
        private const val REANALYZE_EVERY = 50  // প্রতি ৫০ sent message এ

        private val KEY_STYLE_JSON     = stringPreferencesKey("style_config_json")
        private val KEY_SENT_COUNT     = longPreferencesKey("sent_message_count")
        private val KEY_MANUAL_STYLE   = stringPreferencesKey("manual_style_overrides")
    }

    private val gson = Gson()

    // ══════════════════════════════════════════════════════════
    // GET CURRENT STYLE — cached or fresh
    // ══════════════════════════════════════════════════════════
    suspend fun getCurrentStyle(): StyleConfig {
        return try {
            val prefs = context.styleDataStore.data.first()
            val json = prefs[KEY_STYLE_JSON]
            if (json != null) {
                gson.fromJson(json, StyleConfig::class.java)
            } else {
                // First time — analyze করো
                analyzeAndSave()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading style: ${e.message}")
            StyleConfig()   // default
        }
    }

    // ══════════════════════════════════════════════════════════
    // ON SENT MESSAGE — count বাড়াও, দরকারে re-analyze
    // ══════════════════════════════════════════════════════════
    suspend fun onMessageSent() {
        context.styleDataStore.edit { prefs ->
            val count = (prefs[KEY_SENT_COUNT] ?: 0L) + 1
            prefs[KEY_SENT_COUNT] = count

            // প্রতি N message এ re-analyze
            if (count % REANALYZE_EVERY == 0L) {
                Log.d(TAG, "Re-analyzing style after $count sent messages")
            }
        }

        val count = context.styleDataStore.data.first()[KEY_SENT_COUNT] ?: 0
        if (count % REANALYZE_EVERY == 0L) {
            analyzeAndSave()
        }
    }

    // ══════════════════════════════════════════════════════════
    // ANALYZE AND SAVE
    // ══════════════════════════════════════════════════════════
    suspend fun analyzeAndSave(): StyleConfig {
        return try {
            // DB থেকে Sadi এর sent messages নিয়ে আসো
            // (isReplied = true মানে Sadi sent করেছে)
            val sentMessages = repository.getSadiSentMessages()
                .map { it.messageText }

            val config = if (sentMessages.size >= 5) {
                styleAnalyzer.analyze(sentMessages)
            } else {
                Log.d(TAG, "Not enough sent messages, using defaults")
                StyleConfig()
            }

            // Save করো
            context.styleDataStore.edit { prefs ->
                prefs[KEY_STYLE_JSON] = gson.toJson(config)
            }

            Log.d(TAG, "Style config saved: ${config.sentenceStyle}, emoji: ${config.emojiFrequency}")
            config
        } catch (e: Exception) {
            Log.e(TAG, "Style analysis failed: ${e.message}")
            StyleConfig()
        }
    }

    // ══════════════════════════════════════════════════════════
    // MANUAL OVERRIDE — তুমি manually style set করতে পারবে
    // ══════════════════════════════════════════════════════════
    suspend fun applyManualOverride(override: StyleOverride) {
        val current = getCurrentStyle()
        val updated = when (override) {
            is StyleOverride.EmojiFrequency  -> current.copy(emojiFrequency = override.freq)
            is StyleOverride.SentenceLength  -> current.copy(sentenceStyle = override.style)
            is StyleOverride.PunctuationStyle -> current.copy(punctuationStyle = override.style)
            is StyleOverride.AddSlang        -> current.copy(usesSlang = (current.usesSlang + override.word).distinct())
            is StyleOverride.RemoveSlang     -> current.copy(usesSlang = current.usesSlang - override.word)
        }
        context.styleDataStore.edit { prefs ->
            prefs[KEY_STYLE_JSON] = gson.toJson(updated)
        }
    }

    // Style as Flow (UI observe করতে পারবে)
    val styleFlow: Flow<StyleConfig> = context.styleDataStore.data.map { prefs ->
        try {
            val json = prefs[KEY_STYLE_JSON]
            if (json != null) gson.fromJson(json, StyleConfig::class.java)
            else StyleConfig()
        } catch (e: Exception) { StyleConfig() }
    }
}

// Manual override sealed class
sealed class StyleOverride {
    data class EmojiFrequency(val freq: com.sadi.secretary.style.EmojiFreq) : StyleOverride()
    data class SentenceLength(val style: SentenceStyle) : StyleOverride()
    data class PunctuationStyle(val style: com.sadi.secretary.style.PuncStyle) : StyleOverride()
    data class AddSlang(val word: String) : StyleOverride()
    data class RemoveSlang(val word: String) : StyleOverride()
}
