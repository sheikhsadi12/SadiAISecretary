package com.sadi.secretary.ui.dashboard

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — DashboardScreen.kt                 ║
// ║       Phase 10 · Main Control Panel                          ║
// ║                                                              ║
// ║  সব control এক জায়গায়:                                       ║
// ║    → AI status + quick toggles                               ║
// ║    → Today's stats                                           ║
// ║    → Pending replies count                                   ║
// ║    → Recent activity                                         ║
// ║    → Quick mode buttons                                      ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel(),
    onNavigateToPending: () -> Unit = {},
    onNavigateToContacts: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(scrollState)) {

            // ── Top Bar ────────────────────────────────────────
            DashboardTopBar()

            // ── AI Status Hero Card ────────────────────────────
            AiStatusCard(
                isActive   = uiState.isAiActive,
                isBusy     = uiState.isBusyMode,
                isFaith    = uiState.isFaithMode,
                onToggleAi = { viewModel.toggleAi() }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Quick Mode Buttons ─────────────────────────────
            SectionLabel("QUICK MODES")
            QuickModeButtons(
                isBusy   = uiState.isBusyMode,
                isFaith  = uiState.isFaithMode,
                isSilent = uiState.isSilentMode,
                onBusy   = { viewModel.toggleBusy() },
                onFaith  = { viewModel.toggleFaith() },
                onSilent = { viewModel.toggleSilent() }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Today's Stats ──────────────────────────────────
            SectionLabel("আজকের Stats")
            StatsGrid(stats = uiState.todayStats)

            Spacer(modifier = Modifier.height(16.dp))

            // ── Pending Replies ────────────────────────────────
            if (uiState.pendingCount > 0) {
                PendingAlertCard(
                    count   = uiState.pendingCount,
                    onClick = onNavigateToPending
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // ── Recent Activity ────────────────────────────────
            SectionLabel("সাম্প্রতিক Activity")
            RecentActivityList(activities = uiState.recentActivities)

            // ── Provider Info ──────────────────────────────────
            Spacer(modifier = Modifier.height(16.dp))
            SectionLabel("AI PROVIDER")
            ProviderStatusCard(
                providerName = uiState.activeProviderName,
                isConfigured = uiState.isProviderConfigured
            )

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ══════════════════════════════════════════════════════════════
// TOP BAR
// ══════════════════════════════════════════════════════════════
@Composable
private fun DashboardTopBar() {
    Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Sadi AI Secretary", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Digital You System", fontSize = 11.sp, color = Color(0xFF475569))
            }
            // Notification dot
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(Color(0xFF34D399), CircleShape)
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════
// AI STATUS HERO CARD
// ══════════════════════════════════════════════════════════════
@Composable
private fun AiStatusCard(
    isActive: Boolean,
    isBusy: Boolean,
    isFaith: Boolean,
    onToggleAi: () -> Unit
) {
    // Pulse animation when active
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOut),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) Color(0xFF0A2018) else Color(0xFF1A0505)
        ),
        border = BorderStroke(
            1.dp,
            if (isActive) Color(0xFF34D399).copy(alpha = 0.5f) else Color(0xFF7F1D1D)
        )
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Status indicator
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .scale(if (isActive) pulse else 1f)
                    .background(
                        if (isActive) Color(0xFF34D399).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(if (isActive) "🤖" else "💤", fontSize = 24.sp)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (isActive) "AI Secretary চলছে" else "AI Secretary বন্ধ",
                    fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    color = if (isActive) Color(0xFF34D399) else Color(0xFFFCA5A5)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                    if (isBusy)  MiniTag("⏳ Busy",  Color(0xFFFCD34D))
                    if (isFaith) MiniTag("🕌 Faith", Color(0xFF5EEAD4))
                    if (!isBusy && !isFaith && isActive) MiniTag("✅ Normal", Color(0xFF34D399))
                }
            }

            Switch(
                checked = isActive,
                onCheckedChange = { onToggleAi() },
                colors = SwitchDefaults.colors(
                    checkedTrackColor   = Color(0xFF34D399).copy(alpha = 0.7f),
                    uncheckedTrackColor = Color(0xFF3F1010),
                    checkedThumbColor   = Color.White
                )
            )
        }
    }
}

@Composable
private fun MiniTag(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(4.dp), color = color.copy(alpha = 0.1f)) {
        Text(text, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, color = color)
    }
}

// ══════════════════════════════════════════════════════════════
// QUICK MODE BUTTONS
// ══════════════════════════════════════════════════════════════
@Composable
private fun QuickModeButtons(
    isBusy: Boolean, isFaith: Boolean, isSilent: Boolean,
    onBusy: () -> Unit, onFaith: () -> Unit, onSilent: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        QuickModeBtn("⏳", "Busy",   isBusy,  Color(0xFFFCD34D), onBusy,  Modifier.weight(1f))
        QuickModeBtn("🕌", "Faith",  isFaith, Color(0xFF5EEAD4), onFaith, Modifier.weight(1f))
        QuickModeBtn("🔇", "Silent", isSilent,Color(0xFFFCA5A5), onSilent,Modifier.weight(1f))
    }
}

@Composable
private fun QuickModeBtn(
    emoji: String, label: String, isOn: Boolean,
    color: Color, onClick: () -> Unit, modifier: Modifier
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isOn) color.copy(alpha = 0.12f) else Color(0xFF111827)
        ),
        border = BorderStroke(1.dp, if (isOn) color.copy(alpha = 0.5f) else Color(0xFF1E2D45))
    ) {
        Column(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (isOn) color else Color(0xFF64748B))
            Text(if (isOn) "ON" else "OFF", fontSize = 10.sp, color = if (isOn) color else Color(0xFF334155))
        }
    }
}

// ══════════════════════════════════════════════════════════════
// STATS GRID
// ══════════════════════════════════════════════════════════════
data class TodayStats(
    val messagesReceived: Int = 0,
    val repliesSent: Int = 0,
    val autoSent: Int = 0,
    val pending: Int = 0
)

@Composable
private fun StatsGrid(stats: TodayStats) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard("📩", "${stats.messagesReceived}", "Received",  Color(0xFF00D4FF), Modifier.weight(1f))
        StatCard("✅", "${stats.repliesSent}",      "Sent",      Color(0xFF34D399), Modifier.weight(1f))
        StatCard("⚡", "${stats.autoSent}",         "Auto",      Color(0xFFA78BFA), Modifier.weight(1f))
        StatCard("⏳", "${stats.pending}",          "Pending",   Color(0xFFFCD34D), Modifier.weight(1f))
    }
}

@Composable
private fun StatCard(emoji: String, value: String, label: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 16.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, fontSize = 10.sp, color = Color(0xFF475569))
        }
    }
}

// ══════════════════════════════════════════════════════════════
// PENDING ALERT
// ══════════════════════════════════════════════════════════════
@Composable
private fun PendingAlertCard(count: Int, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A0A)),
        border = BorderStroke(1.dp, Color(0xFFFCD34D).copy(alpha = 0.5f))
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("⏳", fontSize = 24.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("$count টা reply তোমার approval এর অপেক্ষায়", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCD34D))
                Text("দেখতে tap করো", fontSize = 12.sp, color = Color(0xFF64748B))
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFFCD34D))
        }
    }
}

// ══════════════════════════════════════════════════════════════
// RECENT ACTIVITY
// ══════════════════════════════════════════════════════════════
data class ActivityItem(val emoji: String, val text: String, val time: String, val color: Color)

@Composable
private fun RecentActivityList(activities: List<ActivityItem>) {
    if (activities.isEmpty()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            border = BorderStroke(1.dp, Color(0xFF1E2D45))
        ) {
            Text(
                "এখনো কোনো activity নেই",
                modifier = Modifier.padding(16.dp),
                fontSize = 13.sp,
                color = Color(0xFF475569)
            )
        }
        return
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column {
            activities.forEachIndexed { i, item ->
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(item.emoji, fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(item.text, fontSize = 13.sp, color = Color(0xFF94A3B8), modifier = Modifier.weight(1f))
                    Text(item.time, fontSize = 11.sp, color = Color(0xFF475569))
                }
                if (i < activities.lastIndex) Divider(color = Color(0xFF1E2D45))
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// PROVIDER STATUS
// ══════════════════════════════════════════════════════════════
@Composable
private fun ProviderStatusCard(providerName: String, isConfigured: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🧠", fontSize = 20.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Active AI: $providerName", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    if (isConfigured) "API key configured ✅" else "API key missing ⚠️",
                    fontSize = 12.sp,
                    color = if (isConfigured) Color(0xFF34D399) else Color(0xFFFCD34D)
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text, fontSize = 10.sp, color = Color(0xFF64748B),
        fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}
